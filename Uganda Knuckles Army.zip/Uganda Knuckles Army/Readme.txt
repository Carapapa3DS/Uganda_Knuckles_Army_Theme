Uganda Knuckles Army v1.2

Created by: Carapapa

Twitter: @carapapa_amigo

Please don't upload my themes to other websites without the my permission!




Theme Download Link: 
https://github.com/Carapapa3DS/Uganda_Knuckles_Army_Theme